import fs from "fs"; 

export default function fileService(req, res) {
    // function read(callback) {
    //     fs.readFile("./data/DbData.json", "utf8", (err, data) => {
    //         if (err) {
    //             return callback(err);
    //         } else {
    //             callback(null, data);
    //         }
    //     });
    // }

    // read((err, data) => {
    //     if (err) {
    //         console.log(err);
    //         res.status(500);
    //     } else {
    //         console.log(data);
    //         res.status(200).json(data);
    //     }
    // });

    let data = JSON.parse(fs.readFileSync("./data/DbData.json", "utf8"));

    // fs.readFile("./data/DbData.json")
    //     .then(contents => console.log(contents))
    //     .then(x => data = JSON.parse(x))
    //     .catch(err => console.log(err));

    console.log(data);
    
    res.status(200).json(data);
}
