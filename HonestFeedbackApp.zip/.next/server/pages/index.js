(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 861:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "styles_root__JFJqa",
	"quoteInput": "styles_quoteInput__YPVw6",
	"submitQuote": "styles_submitQuote__wSgAl"
};


/***/ }),

/***/ 96:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "@aws-sdk/client-dynamodb"
const client_dynamodb_namespaceObject = require("@aws-sdk/client-dynamodb");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./styles/index.module.css
var index_module = __webpack_require__(861);
var index_module_default = /*#__PURE__*/__webpack_require__.n(index_module);
;// CONCATENATED MODULE: ./package.json
const package_namespaceObject = JSON.parse('{"v1":{"BL":"next start -- --port $PORT"}}');
;// CONCATENATED MODULE: ./pages/index.js





const startCommand = package_namespaceObject.v1.BL.split(" ");
// const PORT = startCommand[startCommand.length - 1]; 
const PORT = process.env.port || 8080;
// ddb: the DynamoDBClient used to interact with the DynamoDB service
let ddb = {};
// uploadQuote: uploads a piece of feedback to the DynamoDB table
function uploadQuote(dbData, inputtedQuote) {
    // Ignore empty feedback
    if (inputtedQuote.trim() === "") {
        return;
    }
    // Parameters to send to DynamoDB
    const params = {
        TableName: dbData.TableName,
        Item: {
            quoteId: {
                N: `${dbData.TableItemCount}`
            },
            quote: {
                S: inputtedQuote
            }
        }
    };
    const command = new client_dynamodb_namespaceObject.PutItemCommand(params);
    // Run the PutItemCommand to put an item into the database, and resolve the Promise
    ddb.send(command).then((data)=>console.log(`Successfully uploaded data to DynamoDB table\n${data}`)).catch((err)=>console.log(`Error uploading data to DynamoDB table\n${err}`));
    dbData.TableItemCount++;
    // Replace the data in the json file with an updated TableItemCount
    fetch(`http://localhost:${PORT}/api/update-db-data`, {
        method: "PUT",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(dbData, null, 4)
    });
}
// Page: the component for the main page
function Page(props) {
    const [input, setInput] = external_react_default().useState("");
    let quote = "";
    // Handle if there is an error 
    if (props.error) {
        console.log(props.error);
        quote = props.error;
    } else {
        quote = props.quote;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (index_module_default()).root,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: quote
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                value: input,
                itemID: (index_module_default()).quoteInput,
                onChange: (e)=>setInput(e.target.value)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                itemID: (index_module_default()).submitQuote,
                onClick: ()=>uploadQuote(props.data, input),
                children: "Submit"
            })
        ]
    });
}
async function getServerSideProps() {
    // Get the ddb client credentials    
    const ddbCredentials = await fetch(`http://localhost:${PORT}/api/get-api-keys`).then((res)=>res.json()).catch((err)=>console.log(err));
    // Instantiate the ddb client object
    ddb = new client_dynamodb_namespaceObject.DynamoDBClient({
        credentials: ddbCredentials,
        region: "us-east-1"
    });
    // Get the table's data from the json file
    const dbData = await fetch(`http://localhost:${PORT}/api/read-db-data`).then((res)=>res.json());
    let props = {
        data: dbData
    };
    if (dbData.TableItemCount === 0) {
        props.error = "No feedback in the database!";
        return {
            props
        };
    }
    const params = {
        TableName: dbData.TableName,
        Key: {
            "quoteId": {
                N: `${Math.floor(Math.random() * dbData.TableItemCount)}`
            }
        }
    };
    const command = new client_dynamodb_namespaceObject.GetItemCommand(params);
    // Read one piece of data from the DynamoDB table and deal with any errors
    try {
        const data = await ddb.send(command);
        props.quote = data.Item.quote.S;
    } catch (err) {
        console.log(err);
        props.error = "Error fetching feedback from the database.";
    }
    return {
        props
    };
}


/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(96));
module.exports = __webpack_exports__;

})();