(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 861:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "styles_root__JFJqa",
	"quoteInput": "styles_quoteInput__YPVw6",
	"submitQuote": "styles_submitQuote__wSgAl"
};


/***/ }),

/***/ 369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Page),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_index_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(861);
/* harmony import */ var _styles_index_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_index_module_css__WEBPACK_IMPORTED_MODULE_2__);



const _PORT = process.env.port || 8080;
// uploadQuote: uploads a piece of feedback to the DynamoDB table
function uploadQuote(_dbData, inputtedQuote) {
    // Ignore empty feedback
    if (inputtedQuote.trim() === "") {
        return;
    }
    fetch(`http://localhost:${_PORT}/api/upload-data-ddb`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            PORT: _PORT,
            dbData: _dbData,
            quote: inputtedQuote
        })
    });
    _dbData.TableItemCount++;
    // Replace the data in the json file with an updated TableItemCount
    fetch(`http://localhost:${_PORT}/api/update-db-data`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(_dbData)
    });
}
// Page: the component for the main page
function Page(props) {
    const [input, setInput] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    let quote = "";
    // Handle if there is an error 
    if (props.error) {
        console.log(props.error);
        quote = props.error;
    } else {
        quote = props.quote;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_index_module_css__WEBPACK_IMPORTED_MODULE_2___default().root),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: quote
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                value: input,
                itemID: (_styles_index_module_css__WEBPACK_IMPORTED_MODULE_2___default().quoteInput),
                onChange: (e)=>setInput(e.target.value)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                itemID: (_styles_index_module_css__WEBPACK_IMPORTED_MODULE_2___default().submitQuote),
                onClick: ()=>uploadQuote(props.data, input),
                children: "Submit"
            })
        ]
    });
}
async function getServerSideProps() {
    // Get the table's data from the json file
    const _dbData = await fetch(`http://localhost:${_PORT}/api/read-db-data`).then((res)=>res.json());
    let props = {
        data: _dbData
    };
    if (_dbData.TableItemCount === 0) {
        props.error = "No feedback in the database!";
        return {
            props
        };
    }
    const quote = await fetch(`http://localhost:${_PORT}/api/read-db-quote`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            PORT: _PORT,
            dbData: _dbData
        })
    }).then((res)=>res.json()).then((data)=>data.quote).catch((err)=>{
        console.log(err);
        props.error = "Error reading data from the DynamoDB table.";
    });
    props.quote = quote;
    return {
        props
    };
}


/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(369));
module.exports = __webpack_exports__;

})();