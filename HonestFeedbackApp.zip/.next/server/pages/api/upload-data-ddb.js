"use strict";
(() => {
var exports = {};
exports.id = 268;
exports.ids = [268];
exports.modules = {

/***/ 317:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-dynamodb");

/***/ }),

/***/ 316:
/***/ ((module) => {

module.exports = require("request-ip");

/***/ }),

/***/ 630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ uploadToDDB)
/* harmony export */ });
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(317);
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__);

const requestIp = __webpack_require__(316);
async function uploadToDDB(req, res) {
    function isLocalIP(ip) {
        if (!(ip === "::1" || ip === "127.0.0.1" || ip === "::ffff:127.0.0.1")) {
            return false;
        }
        return true;
    }
    const ip = requestIp.getClientIp(req);
    if (!isLocalIP(ip)) {
        res.status(400);
        return;
    }
    const ddbCredentials = await fetch(`http://localhost:${req.body.PORT}/api/get-api-keys`).then((res)=>res.json()).catch((err)=>console.log(err));
    const client = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__.DynamoDBClient({
        credentials: ddbCredentials,
        region: "us-east-1"
    });
    // Parameters to send to DynamoDB
    const params = {
        TableName: req.body.dbData.TableName,
        Item: {
            quoteId: {
                N: `${req.body.dbData.TableItemCount}`
            },
            quote: {
                S: req.body.quote
            }
        }
    };
    const command = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__.PutItemCommand(params);
    // Run the PutItemCommand to put an item into the database
    try {
        const data = await client.send(command);
        console.log(`Successfully uploaded data to DynamoDB table\n${data}`);
        res.status(200);
    } catch (err) {
        console.log(`Error uploading data to DynamoDB table\n${err}`);
        res.status(500).json({
            error: err
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(630));
module.exports = __webpack_exports__;

})();