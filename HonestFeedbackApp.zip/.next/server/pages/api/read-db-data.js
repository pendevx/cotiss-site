"use strict";
(() => {
var exports = {};
exports.id = 564;
exports.ids = [564];
exports.modules = {

/***/ 147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 94:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ fileService)
/* harmony export */ });
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);

function fileService(req, res) {
    // function read(callback) {
    //     fs.readFile("./data/DbData.json", "utf8", (err, data) => {
    //         if (err) {
    //             return callback(err);
    //         } else {
    //             callback(null, data);
    //         }
    //     });
    // }
    // read((err, data) => {
    //     if (err) {
    //         console.log(err);
    //         res.status(500);
    //     } else {
    //         console.log(data);
    //         res.status(200).json(data);
    //     }
    // });
    let data = JSON.parse(fs__WEBPACK_IMPORTED_MODULE_0___default().readFileSync("./data/DbData.json", "utf8"));
    // fs.readFile("./data/DbData.json")
    //     .then(contents => console.log(contents))
    //     .then(x => data = JSON.parse(x))
    //     .catch(err => console.log(err));
    console.log(data);
    res.status(200).json(data);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(94));
module.exports = __webpack_exports__;

})();