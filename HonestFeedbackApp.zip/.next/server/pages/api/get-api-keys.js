"use strict";
(() => {
var exports = {};
exports.id = 711;
exports.ids = [711];
exports.modules = {

/***/ 316:
/***/ ((module) => {

module.exports = require("request-ip");

/***/ }),

/***/ 818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getApiKeys)
/* harmony export */ });
const requestIp = __webpack_require__(316);
function getApiKeys(req, res) {
    function isLocalIP(ip) {
        if (!(ip === "::1" || ip === "127.0.0.1" || ip === "::ffff:127.0.0.1")) {
            return false;
        }
        return true;
    }
    const ip = requestIp.getClientIp(req);
    if (!isLocalIP(ip)) {
        res.status(400);
        return;
    }
    res.status(200).json({
        accessKeyId: process.env.DDB_Quotes_AKI,
        secretAccessKey: process.env.DDB_Quotes_SAK
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(818));
module.exports = __webpack_exports__;

})();