"use strict";
(() => {
var exports = {};
exports.id = 556;
exports.ids = [556];
exports.modules = {

/***/ 317:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-dynamodb");

/***/ }),

/***/ 316:
/***/ ((module) => {

module.exports = require("request-ip");

/***/ }),

/***/ 977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ uploadToDDB)
/* harmony export */ });
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(317);
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__);

const requestIp = __webpack_require__(316);
async function uploadToDDB(req, res) {
    function isLocalIP(ip) {
        if (!(ip === "::1" || ip === "127.0.0.1" || ip === "::ffff:127.0.0.1")) {
            return false;
        }
        return true;
    }
    const ip = requestIp.getClientIp(req);
    if (!isLocalIP(ip)) {
        res.status(400);
        return;
    }
    const ddbCredentials = await fetch(`http://localhost:${req.body.PORT}/api/get-api-keys`).then((res)=>res.json()).catch((err)=>console.log(err));
    const client = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__.DynamoDBClient({
        credentials: ddbCredentials,
        region: "us-east-1"
    });
    const params = {
        TableName: req.body.dbData.TableName,
        Key: {
            "quoteId": {
                N: `${Math.floor(Math.random() * req.body.dbData.TableItemCount)}`
            }
        }
    };
    const command = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_0__.GetItemCommand(params);
    try {
        const data = await client.send(command);
        const quote = data.Item.quote.S;
        console.log(data);
        res.status(200).json({
            quote: quote
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error fetching data from DynamoDB table"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(977));
module.exports = __webpack_exports__;

})();